package mrj;

class Cls {
    public Cls() {
    }

    public int getVersion() {
        return getVersionStatic();
    }

    public static int getVersionStatic() {
        return 8;
    }
}

