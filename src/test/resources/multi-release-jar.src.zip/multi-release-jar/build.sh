#!/bin/bash

javac --release 8 -d classes src/main/java/mrj/Cls.java 
javac --release 9 -d classes-9 src/main/java-9/mrj/Cls.java 
cp src/main/java/resource.txt classes
cp src/main/java-9/resource.txt classes-9
mkdir -p target
jar --create --file target/multi-release-jar.jar -C classes . --release 9 -C classes-9 .

