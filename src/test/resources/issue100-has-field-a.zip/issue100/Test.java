package issue100;

public class Test {
    public int a;
}

