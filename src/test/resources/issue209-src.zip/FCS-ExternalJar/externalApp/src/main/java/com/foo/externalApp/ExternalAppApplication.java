package com.foo.externalApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExternalAppApplication {

  public static void main(String[] args) {
    SpringApplication.run(ExternalAppApplication.class, args);
  }
}
