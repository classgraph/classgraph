package com.scanner;

import static org.hamcrest.MatcherAssert.assertThat;

import java.net.MalformedURLException;
import org.junit.Test;


public class AppTest {

  /*
  The external jar has at least two classes the main class and someClass.
  This test should pass as soon as the matcher finds those two.
   */
  @Test
  public void shouldFindClass() throws MalformedURLException {
    Scanner scanner = new Scanner();
    int classes = scanner.scan();
    assertThat("Found at least 2 classes", classes >= 2);
  }
}
