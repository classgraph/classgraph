package com.scanner;

import com.lib.externalLib.FooAnnotation;
import io.github.lukehutch.fastclasspathscanner.FastClasspathScanner;
import io.github.lukehutch.fastclasspathscanner.matchprocessor.ClassAnnotationMatchProcessor;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;


public class ScannerMain {
  public static void main(String[] args) throws MalformedURLException {
    Scanner scanner = new Scanner();
    scanner.scan();
  }
}

class ClassFooAnnotation implements ClassAnnotationMatchProcessor {

  @Override
  public void processMatch(Class<?> classWithAnnotation) {
    System.out.println("Class foo annotaation");
  }
}

class Scanner {
  public int scan() throws MalformedURLException {
    // TODO Update with correct path
    final String sampleJar = "/Users/yuniorb/Downloads/externalApp/target/externalApp.jar";

    String jar = "file://" + sampleJar;

    ClassLoader loader = new URLClassLoader(new URL[]{new URL(jar)});
    ClassMatcher matcher = new ClassMatcher();

    FooAnnotationProcessor processor = new FooAnnotationProcessor();
    ClassFooAnnotation k = new ClassFooAnnotation();

    new FastClasspathScanner()
        .addClassLoader(loader)
        .addNestedLibJarsToClasspath(true)
        .matchAllClasses(matcher)
        .matchClassesWithAnnotation(FooAnnotation.class, k)
        .matchClassesWithMethodAnnotation(FooAnnotation.class, processor)
        .verbose()
        .scan();
    return matcher.classesFound;
  }
}
