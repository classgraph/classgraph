package com.scanner;

import io.github.lukehutch.fastclasspathscanner.matchprocessor.MethodAnnotationMatchProcessor;
import java.lang.reflect.Executable;

public class FooAnnotationProcessor implements MethodAnnotationMatchProcessor {
  @Override
  public void processMatch(Class<?> matchingClass, Executable matchingMethodOrConstructor) {
    System.out.println("Foo annotation Processor");
  }
}
