package com.lib.externalLib;

public class BaseClass {
}
