package com.lib.externalLib;


public abstract class AbstractaseClass<I> extends BaseClass {
}
